<h1>Регистрация</h1>
<form method="POST" action="?signup">
  <div class="row">
    <label for="email">Email:</label>
    <input name="email" id="email" autocomplete="off" />
  </div>
  <div class="row">
    <label for="pass1">Пароль:</label>
    <input type="password" name="pass1" id="pass1" />
  </div>
  <div class="row">
    <label for="pass2">Повтор пароля:</label>
    <input type="password" name="pass2" id="pass2" />
  </div>
  <div class="row">
    <a href="/">Вход</a>
  </div>
  <div class="row">
    <input type="submit" />
  </div>  
</form>