<h1>Восстановление пароля: шаг 1 из 2</h1>
<form method="POST" action="?recovery">
  <div class="row">
    <label for="email">Email:</label>
    <input name="email" id="email" autocomplete="off" />
  </div>
  <div class="row">
    <a href="/">Вход</a>
  </div>
  <div class="row">
    <input type="submit" />
  </div>  
</form>