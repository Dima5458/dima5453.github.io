<h1>Восстановление пароля: шаг 2 из 2</h1>
<form method="POST" >
  <div class="row">
    <label for="pass1">Пароль:</label>
    <input type="password" name="pass1" id="pass1" />
  </div>
  <div class="row">
    <label for="pass2">Повтор пароля:</label>
    <input type="password" name="pass2" id="pass2" />
  </div>
  <div class="row">
    <a href="/">Вход</a>
  </div>
  <div class="row">
    <input type="submit" />
  </div>  
</form>
<!-- <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Ubuntu+Condensed&display=swap" rel="stylesheet">
<style>
*{
  font-family: 'Ubuntu Condensed', sans-serif; 
}</style> -->